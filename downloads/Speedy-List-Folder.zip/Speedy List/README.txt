SPEEDY LIST AI - YOUR SPEEDY LIST FOLDER
List it fast. Sell it faster.
==========================================

HOW TO USE THIS FOLDER
1. Snap photos of your equipment (reach-ins, ranges, mixers, fryers, ice machines...).
2. Drop the photos into the "Drop Photos Here" folder.
3. Open the Speedy List AI app and drag those photos into the
   "Drop a photo of your equipment" box (or tap it on your phone).
4. The app identifies the item, prices it, writes the listing,
   and posts it to your marketplaces.
5. Move the photos to "Listed" once the item is live, and to "Sold"
   when it's gone. That's your whole inventory system.

WHAT'S INSIDE
  Drop Photos Here\     new equipment photos waiting to be listed
  Listed\               photos of items that are live
  Sold\                 photos of items that sold (handy for comps)
  folder.ico            Windows folder icon (roadrunner on a folder)
  desktop.ini           tells Windows to use folder.ico
  folder-icon-1024.png  large icon for macOS (and anywhere else)
  folder.icns           macOS icon file (optional)
  SET-FOLDER-ICON-WINDOWS.txt
  SET-FOLDER-ICON-MAC.txt

PHOTO TIPS
  - Shoot the whole unit straight on, then the data plate (model/serial),
    the controls, the inside, and any dents or wear.
  - Daylight or bright shop lights. No flash glare on stainless.
  - 3-8 photos per item is the sweet spot.

NOTE: Speedy List AI is a prototype. AI identification, pricing and
marketplace posting in the current app are DEMOS.

Questions: justaskmiggy@gmail.com
Web: speedylistai.com (coming soon)
